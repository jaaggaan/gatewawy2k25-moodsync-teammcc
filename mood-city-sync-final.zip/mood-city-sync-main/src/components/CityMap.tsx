import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default markers in Leaflet with Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface MapProps {
  center?: [number, number];
  zoom?: number;
  className?: string;
}

const CityMap = ({ center = [12.9716, 77.5946], zoom = 11, className = "" }: MapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Initialize map
    const map = L.map(mapRef.current).setView(center, zoom);
    mapInstanceRef.current = map;

    // Add OpenStreetMap tiles (free)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    // Custom icons for different mood zones
    const calmIcon = L.divIcon({
      className: 'custom-div-icon',
      html: "<div style='background-color: hsl(180, 90%, 35%); width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);'></div>",
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    const energeticIcon = L.divIcon({
      className: 'custom-div-icon',
      html: "<div style='background-color: hsl(25, 95%, 60%); width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);'></div>",
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    const crowdedIcon = L.divIcon({
      className: 'custom-div-icon',
      html: "<div style='background-color: hsl(0, 90%, 60%); width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);'></div>",
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    // Add sample markers for Bangalore areas
    const markers = [
      { coords: [12.9352, 77.6245] as [number, number], type: 'calm', title: 'Cubbon Park - Calm Zone', description: 'Perfect for peaceful walks and morning jogs' },
      { coords: [12.9698, 77.7500] as [number, number], type: 'energetic', title: 'Whitefield - Tech Hub', description: 'Bustling IT corridor with cafes and events' },
      { coords: [12.9279, 77.6271] as [number, number], type: 'energetic', title: 'Brigade Road - Shopping District', description: 'Popular shopping and entertainment area' },
      { coords: [12.9716, 77.5946] as [number, number], type: 'crowded', title: 'MG Road - Business District', description: 'Central business area with high activity' },
      { coords: [12.9342, 77.6101] as [number, number], type: 'calm', title: 'Lalbagh - Garden Area', description: 'Peaceful botanical garden for relaxation' },
      { coords: [13.0358, 77.5970] as [number, number], type: 'energetic', title: 'Koramangala - Social Hub', description: 'Trendy area with pubs, cafes and startups' },
    ];

    markers.forEach(marker => {
      let icon;
      switch (marker.type) {
        case 'calm': icon = calmIcon; break;
        case 'energetic': icon = energeticIcon; break;
        case 'crowded': icon = crowdedIcon; break;
        default: icon = calmIcon;
      }

      L.marker(marker.coords, { icon })
        .addTo(map)
        .bindPopup(`
          <div style="font-family: Inter, sans-serif;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600;">${marker.title}</h3>
            <p style="margin: 0; font-size: 12px; color: #666;">${marker.description}</p>
            <div style="margin-top: 8px;">
              <span style="display: inline-block; padding: 2px 8px; background: ${
                marker.type === 'calm' ? 'hsl(180, 90%, 35%)' : 
                marker.type === 'energetic' ? 'hsl(25, 95%, 60%)' : 'hsl(0, 90%, 60%)'
              }; color: white; border-radius: 12px; font-size: 10px; text-transform: capitalize;">${marker.type}</span>
            </div>
          </div>
        `);
    });

    // Add heat map-like circles for Bangalore areas
    const heatZones = [
      { coords: [12.9698, 77.7500] as [number, number], intensity: 0.8, color: 'red' }, // Whitefield
      { coords: [12.9279, 77.6271] as [number, number], intensity: 0.7, color: 'orange' }, // Brigade Road
      { coords: [12.9352, 77.6245] as [number, number], intensity: 0.2, color: 'blue' }, // Cubbon Park
      { coords: [13.0358, 77.5970] as [number, number], intensity: 0.6, color: 'orange' }, // Koramangala
    ];

    heatZones.forEach(zone => {
      L.circle(zone.coords, {
        color: zone.color,
        fillColor: zone.color,
        fillOpacity: 0.1 + (zone.intensity * 0.2),
        radius: 300 + (zone.intensity * 200)
      }).addTo(map);
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [center, zoom]);

  return (
    <div className={`relative ${className}`}>
      <div ref={mapRef} className="w-full h-full rounded-xl" />
      
      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 glass p-3 rounded-lg text-xs space-y-2">
        <div className="font-semibold text-foreground mb-2">Area Guide</div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full mood-calm"></div>
          <span>Calm Areas</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full mood-energetic"></div>
          <span>Active Zones</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full mood-crowded"></div>
          <span>Crowded Areas</span>
        </div>
      </div>
    </div>
  );
};

export default CityMap;