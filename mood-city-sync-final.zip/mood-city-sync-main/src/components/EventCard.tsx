import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Users, Heart } from "lucide-react";

interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  time: string;
  attendees: number;
  mood: "calm" | "energetic" | "neutral";
  distance: string;
  image?: string;
  tags: string[];
}

interface EventCardProps {
  event: Event;
  onJoin: (eventId: string) => void;
  onLike: (eventId: string) => void;
}

const EventCard = ({ event, onJoin, onLike }: EventCardProps) => {
  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "calm": return "mood-calm";
      case "energetic": return "mood-energetic";
      default: return "mood-neutral";
    }
  };

  return (
    <Card className="glass card-shadow hover:scale-105 transition-smooth overflow-hidden">
      {/* Event Header */}
      <div className="p-4 space-y-3">
        <div className="flex justify-between items-start">
          <Badge className={`${getMoodColor(event.mood)} text-white border-0`}>
            {event.mood}
          </Badge>
          <Button variant="ghost" size="icon" onClick={() => {
            onLike(event.id);
            window.location.href = '/signin';
          }}>
            <Heart className="w-4 h-4" />
          </Button>
        </div>
        
        <h3 className="text-lg font-semibold line-clamp-2">{event.title}</h3>
        <p className="text-foreground/70 text-sm line-clamp-2">{event.description}</p>
      </div>
      
      {/* Event Details */}
      <div className="px-4 space-y-2">
        <div className="flex items-center space-x-2 text-sm text-foreground/60">
          <MapPin className="w-4 h-4" />
          <span>{event.location}</span>
          <span className="text-accent font-medium">• {event.distance}</span>
        </div>
        
        <div className="flex items-center space-x-4 text-sm text-foreground/60">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{event.time}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{event.attendees} going</span>
          </div>
        </div>
      </div>
      
      {/* Tags */}
      <div className="px-4 py-2">
        <div className="flex flex-wrap gap-1">
          {event.tags.slice(0, 3).map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
          {event.tags.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{event.tags.length - 3}
            </Badge>
          )}
        </div>
      </div>
      
      {/* Action Button */}
      <div className="p-4 pt-0">
        <Button 
          variant="accent" 
          size="sm" 
          className="w-full"
          onClick={() => {
            onJoin(event.id);
            window.location.href = '/signin';
          }}
        >
          Join Event
        </Button>
      </div>
    </Card>
  );
};

export default EventCard;