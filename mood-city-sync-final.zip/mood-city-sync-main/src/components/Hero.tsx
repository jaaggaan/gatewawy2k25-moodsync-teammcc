import { Button } from "@/components/ui/button";
import { MapPin, Heart, Zap, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-cityscape.jpg";

const Hero = () => {
  const navigate = useNavigate();
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-background/90 via-background/60 to-background/30" />
      </div>
      
      {/* Floating mood indicators */}
      <div className="absolute top-20 left-10 mood-calm w-4 h-4 rounded-full pulse-mood" />
      <div className="absolute top-32 right-20 mood-energetic w-3 h-3 rounded-full pulse-mood animation-delay-300" />
      <div className="absolute bottom-40 left-20 mood-neutral w-5 h-5 rounded-full pulse-mood animation-delay-600" />
      
      {/* Main Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <div className="mb-8 space-y-2">
          <h1 className="text-6xl md:text-7xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-4">
            CitySync
          </h1>
          <p className="text-xl md:text-2xl text-foreground/80 font-light">
            Find your vibe in the city
          </p>
        </div>
        
        <p className="text-lg text-foreground/70 mb-12 max-w-2xl mx-auto leading-relaxed">
          Discover calm spaces when you need peace, exciting events when you're ready to socialize, 
          and everything in between. Your mood, your city, your way.
        </p>
        
        {/* Feature highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          <div className="glass p-4 rounded-xl card-shadow">
            <MapPin className="w-8 h-8 text-accent mx-auto mb-2" />
            <p className="text-sm font-medium">Heat Maps</p>
          </div>
          <div className="glass p-4 rounded-xl card-shadow">
            <Heart className="w-8 h-8 text-mood-calm mx-auto mb-2" />
            <p className="text-sm font-medium">Connect</p>
          </div>
          <div className="glass p-4 rounded-xl card-shadow">
            <Zap className="w-8 h-8 text-mood-energetic mx-auto mb-2" />
            <p className="text-sm font-medium">Live Events</p>
          </div>
          <div className="glass p-4 rounded-xl card-shadow">
            <Users className="w-8 h-8 text-primary mx-auto mb-2" />
            <p className="text-sm font-medium">Community</p>
          </div>
        </div>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            variant="hero" 
            size="lg" 
            className="px-8 py-3 text-lg"
            onClick={() => navigate("/signin")}
          >
            Get Started
          </Button>
          <Button 
            variant="mood" 
            size="lg" 
            className="px-8 py-3 text-lg"
            onClick={() => navigate("/signin")}
          >
            Learn More
          </Button>
        </div>
        
        {/* Stats */}
        <div className="mt-16 pt-8 border-t border-white/20">
          <div className="grid grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-accent">24/7</div>
              <div className="text-sm text-foreground/60">Live Updates</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">15km</div>
              <div className="text-sm text-foreground/60">Radius Coverage</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-mood-energetic">∞</div>
              <div className="text-sm text-foreground/60">Mood Possibilities</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;