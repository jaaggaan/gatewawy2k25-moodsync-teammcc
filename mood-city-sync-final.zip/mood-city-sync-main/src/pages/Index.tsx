import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Hero from "@/components/Hero";
import Navigation from "@/components/Navigation";
import MoodSelector from "@/components/MoodSelector";
import EventCard from "@/components/EventCard";
import MoodCoinDisplay from "@/components/MoodCoinDisplay";
import CityMap from "@/components/CityMap";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Filter, Search } from "lucide-react";

// Mock data for demo
const mockEvents = [
  {
    id: "1",
    title: "Sunset Yoga in Central Park",
    description: "Join us for a peaceful yoga session as the sun sets over the city",
    location: "Central Park, Zone 3",
    time: "6:30 PM Today",
    attendees: 24,
    mood: "calm" as const,
    distance: "2.3km",
    tags: ["Wellness", "Outdoor", "Beginner-friendly"]
  },
  {
    id: "2", 
    title: "Underground Music Showcase",
    description: "Discover emerging artists in this intimate underground venue",
    location: "The Basement Club",
    time: "9:00 PM Tonight",
    attendees: 89,
    mood: "energetic" as const,
    distance: "1.7km",
    tags: ["Music", "Arts", "Nightlife"]
  },
  {
    id: "3",
    title: "Coffee & Code Meetup",
    description: "Productive co-working session with fellow developers and creatives",
    location: "Brew & Build Cafe",
    time: "2:00 PM Tomorrow",
    attendees: 15,
    mood: "neutral" as const,
    distance: "800m",
    tags: ["Tech", "Networking", "Study"]
  }
];

const Index = () => {
  const [currentView, setCurrentView] = useState<"hero" | "app">("hero");
  const [selectedMood, setSelectedMood] = useState<string>("");
  const [showEvents, setShowEvents] = useState<boolean>(false);
  const navigate = useNavigate();
  
  const handleMoodSelect = (mood: string) => {
    setSelectedMood(mood);
    // In a real app, this would filter locations and events
  };
  
  const handleEventJoin = (eventId: string) => {
    console.log("Joining event:", eventId);
    // Handle event joining logic
  };
  
  const handleEventLike = (eventId: string) => {
    console.log("Liking event:", eventId);
    // Handle event liking logic
  };

  if (currentView === "hero") {
    return (
      <div className="min-h-screen">
        <Navigation />
        <Hero />
        
        {/* Quick Demo Section */}
        <div className="relative py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Experience CitySync
              </h2>
              <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
                See how CitySync adapts to your mood and helps you discover the perfect spots in your city
              </p>
            </div>
            
            <div className="space-y-12">
              {/* Mood Selection Demo */}
              <div>
                <MoodSelector onMoodSelect={handleMoodSelect} selectedMood={selectedMood} />
              </div>
              
              {selectedMood && (
                <>
                  {/* Interactive Map */}
                  <Card className="glass card-shadow p-8">
                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-semibold mb-2">Bangalore City Map</h3>
                      <p className="text-foreground/70">Explore popular areas and districts in Bangalore</p>
                    </div>
                    
                    <div className="h-96 rounded-xl overflow-hidden">
                      <CityMap className="w-full h-full" />
                    </div>
                  </Card>
                  
                  {/* Events Section */}
                  <div className="text-center">
                    <Button 
                      size="lg" 
                      variant="accent"
                      onClick={() => setShowEvents(!showEvents)}
                      className="px-8 py-4"
                    >
                      {showEvents ? "Hide Events" : "Events Near Me"}
                    </Button>
                  </div>

                  {showEvents && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-2xl font-semibold">Events Near You</h3>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => navigate("/signin")}>
                            <Filter className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => navigate("/signin")}>
                            <Search className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {mockEvents.map((event) => (
                          <EventCard
                            key={event.id}
                            event={event}
                            onJoin={handleEventJoin}
                            onLike={handleEventLike}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Mood Coins Display */}
                  <div className="max-w-md mx-auto">
                    <MoodCoinDisplay 
                      coins={2847}
                      todayEarned={45}
                      streak={7}
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default Index;
